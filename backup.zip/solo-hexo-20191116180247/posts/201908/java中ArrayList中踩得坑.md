title: java中ArrayList中踩得坑
date: '2019-08-26 18:10:16'
updated: '2019-08-26 22:52:48'
tags: [ArrayList]
permalink: /articles/2019/08/26/1566814216255.html
---
**循环遍历删除元素**

错误写法示例一
```
@Test 
    public void testRemove2(){ 
        ArrayList<Integer> list = new ArrayList<>(); 
        list.add(1); 
        list.add(2); 
        list.add(2); 
        list.add(4); 
        list.add(4); 
        list.add(6); 
        for (int i = 0; i < list.size(); i++){ 
            //删除偶数 
            if(list.get(i)%2 == 0){ 
                list.remove(i);  // -->remove(int index)
            } 
        } 
        System.out.println(toText(list));
        //执行结果：[1,2,4]
        //分析如下  
        i=0时，  1为奇数  不移除数据  size=6  
        i=1时，  2为偶数  移除2  size=5  list：[1,2,4,4,6]  
        i=2时，  4 为偶数 移除4  size=4  list：[1,2,4,6]  
        i=3时，  6为偶数  移除6  size=3  list：[1,2,4]
    }

```

---
错误写法示例二
```
@Test 
    public void testRemove3(){ 
        ArrayList<Integer> list = new ArrayList<>(); 
        list.add(1); 
        list.add(2); 
        list.add(2); 
        list.add(4); 
        list.add(4); 
        list.add(6); 
        for (Integer i:list){ 
            //删除偶数 
            if(i%2 == 0){ 
                list.remove(i);  //删除元素，会触发fastRemove()方法中modCount自增
            } 
        } 
        System.out.println(toText(list)); 
       // 执行结果：报错 java.util.ConcurrentModificationException  并发修改异常
    }
```

二者的错误都是因为这个方法
```
private void fastRemove(int index) {  。 
        modCount++;  
        int numMoved = size - index - 1;  
        if (numMoved > 0)  
            System.arraycopy(elementData, index+1, elementData, index,  
                     numMoved); 
        elementData[--size] = null; // clear to let GC do its work  
    }
```

---
**解决办法**
示例一说明：因为是从前往后遍历，所以当有个索引位置的元素被删除的时候，下一个索引位置的元素会补上来，这就导致下一次遍历，会漏掉这个元素，参见fastRemove方法。

正确的方法是从后往前遍历
```
@Test 
    public void testRemove4(){ 
        ArrayList<Integer> list = new ArrayList<>(); 
        list.add(1); 
        list.add(2); 
        list.add(2); 
        list.add(4); 
        list.add(4); 
        list.add(6); 
        for (int i = list.size()-1; i >= 0; i--){ 
            //删除偶数 
            if(list.get(i)%2 == 0){ 
                list.remove(i); 
            } 
        } 
        System.out.println(toText(list)); 
        //执行结果：1
    }
```
---
示例二说明：foreach循环实际上是对Iterable、hasNext、next方法的简写，如图所示
![image.png](https://img.hacpai.com/file/2019/08/image-3173382e.png)
为什么会出现java.util.ConcurrentModificationException  并发修改异常这个错误。
ArrayList返回的迭代器
```
public Iterator<E> iterator() { 
        return new Itr(); 
    }
```
这里返回的是ArrayList类内部的迭代器实现
`private class Itr implements Iterator<E>`
看这个类的next方法：
```
@SuppressWarnings("unchecked") 
        public E next() { 
            checkForComodification(); 
            int i = cursor; 
            if (i >= size) 
                throw new NoSuchElementException(); 
            Object[] elementData = ArrayList.this.elementData; 
            if (i >= elementData.length) 
                throw new ConcurrentModificationException(); 
            cursor = i + 1; 
            return (E) elementData[lastRet = i]; 
        }
```
执行第一行checkForComodification方法
```
final void checkForComodification() { 
            if (modCount != expectedModCount)  //expectedModCount 默认为modCount，因为之前移除过一次，所以modCount自增了一次，所以抛异常。
                throw new ConcurrentModificationException(); 
        }
```
这里会做迭代器内部修改次数检查，因为上面的remove(Object)方法把修改了modCount的值，所以才会报出并发修改异常。要避免这种情况的出现则在使用迭代器迭代时（显示或foreach的隐式）不要使用ArrayList的remove，改为用Iterator的remove即可
```
public void remove() {   //Iterator的remove方法
            if (lastRet < 0) 
                throw new IllegalStateException(); 
            checkForComodification(); 

            try { 
                ArrayList.this.remove(lastRet); 
                cursor = lastRet; 
                lastRet = -1; 
                expectedModCount = modCount; 
            } catch (IndexOutOfBoundsException ex) { 
                throw new ConcurrentModificationException(); 
            } 
        }
```
```
@Test 
    public void testRemove5() { 
        ArrayList<Integer> list = new ArrayList(); 
        list.add(1); 
        list.add(2); 
        list.add(2); 
        list.add(4); 
        list.add(4); 
        list.add(6); 
        Iterator var2 = list.iterator(); 

        while(var2.hasNext()) { 
            Integer i = (Integer)var2.next(); 
            if (i % 2 == 0) { 
                var2.remove(); 
            } 
        } 
        System.out.println(this.toText(list)); 
        //执行结果：1
    }
```
如有不对之处，欢迎指出。









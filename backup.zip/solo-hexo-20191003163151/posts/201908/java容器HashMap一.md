title: java容器——HashMap(一)
date: '2019-08-19 09:34:16'
updated: '2019-08-19 09:37:05'
tags: [java容器, HashMap]
permalink: /articles/2019/08/19/1566178456884.html
---
![](https://img.hacpai.com/bing/20180623.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


1.new HashMap<>()与new HashMap<>(10)的区别? >

**new HashMap<>()的时候会调用**

![image.png](https://img.hacpai.com/file/2019/08/image-b1a7a9b4.png)
设置默认的加载因子：0.75 

**new HashMap<>(10)会调用**
![image.png](https://img.hacpai.com/file/2019/08/image-98aceed8.png)
然后再去调用
![image.png](https://img.hacpai.com/file/2019/08/image-34b80913.png)
设置扩容的阀值
![image.png](https://img.hacpai.com/file/2019/08/image-3203a4b7.png)
这个方法相当于将cap转化为比它大的2的整数次方 
例子：当cap为9时 
n = 8 （1000） 
n |= n >>> 1  1000 | 0100（n右偏移一位）= 1100 = 12 
n |= n >>> 2  1100 | 0011（n右偏移二位）= 1111 = 15 
剩下的4、8、16 没位置偏移,就不会计算了 
所以最后返回的结果为16. 
new HashMap<>(10)对加载因子与扩容阀值赋值 

总结：二者的都初始化了加载因子(默认为0.75), 后者设置了扩容的阀值；



**2.那么问题来了,HashMap保存key-value的节点数组没有初始化。**

Map<String, String> map = new HashMap<>(); 
map.put("a","1"); 
当我们put第一个key-values值时:
![image.png](https://img.hacpai.com/file/2019/08/image-2b44c76a.png)
调用putVal
![image.png](https://img.hacpai.com/file/2019/08/image-617ecc50.png)
此时的节点数组table并没有被赋予数组对象，所以为null
会执行第1步操作：
调用
![image.png](https://img.hacpai.com/file/2019/08/image-d0b91efd.png)
当我们new hashmap()对象的时候，数组节点table并没有赋值，所以为null； 
所以我们第一次调用put方法时，会执行 3,5。 
当我们new hashmap(10)时，会给threshold赋值，所以就会执行2，节点数组的容量为扩容阀值(threshold)，然后执行4，重新计算扩容的阀值，公式为：容量*加载因子 
最后执行5。 
最后创建一个节点对象。

**总结：本文讲了hashmap初始化的时候，对部分参数进行了初始化操作及保存key-value值的节点数组实例化的过程。**

如有不对之处，欢迎指出。


title: String源码解析
date: '2019-08-19 10:23:36'
updated: '2019-08-19 10:23:36'
tags: [源码]
permalink: /articles/2019/08/19/1566181416893.html
---
![](https://img.hacpai.com/bing/20181029.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![image.png](https://img.hacpai.com/file/2019/08/image-3daaae3d.png)
String类被class修饰就说明不可被继承,是最终类
字符数组被final修饰 说明 字符串是不可变的，赋值之后不可被修改

**方法**
1.equals方法 比较二个数是否相等  重写的object的方法
![image.png](https://img.hacpai.com/file/2019/08/image-83aa3378.png)
第一：与自己的内存地址比较  如果内存地址相同，则这二个字符串相等
第二：判断是否是字符串
第三：判断长度是否相等
第四：一个一个字符比较

如有不对之处，欢迎指出。




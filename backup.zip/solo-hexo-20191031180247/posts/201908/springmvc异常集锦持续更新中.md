title: springmvc异常集锦(持续更新中)
date: '2019-08-29 11:00:20'
updated: '2019-08-29 11:00:20'
tags: [异常, springmvc]
permalink: /articles/2019/08/29/1567047620785.html
---
![](https://img.hacpai.com/bing/20190331.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

异常：HttpMessageNotReadableException: Required request body is missing  报400错误
原因：前端传给后端需要按照指定数据格式传参
解决方式：选择对应的数据格式，如表单或者json格式。

---
title: springmvc:数据的接收
date: '2019-08-29 10:25:14'
updated: '2019-08-29 14:30:04'
tags: [springmvc]
permalink: /articles/2019/08/29/1567045514497.html
---
![](https://img.hacpai.com/bing/20180821.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**数据的接收**
---
```
    /** 
     * 适用与get,post提交 
     * @param username 
     * @param password 
     */ 
    @RequestMapping("/test01") 
    public void test01(String username,String password){ 
        System.out.println("username: " + username); 
        System.out.println("password: " + password); 
    }
```
```
    /** 
     * 通过HttpServletRequest接收 
     * post与get都可以 
     * @param request 
     */ 
    @RequestMapping("/test02") 
    public void test02(HttpServletRequest request){ 
        System.out.println("username: " + request.getParameter("username")); 
        System.out.println("password: " + request.getParameter("password")); 
    }
```
```
    /** 
     * 通过一个bean来接收 
     * post与get都可以 
     * @param user 
     */ 
    @RequestMapping("/test03") 
    public void test03(User user){ 
        System.out.println("username: " + user.getUsername()); 
        System.out.println("password: " + user.getPassword()); 
    }
```
```
    /** 
     * 通过@PathVariabl获取路径中的参数 
     * 该注解用来映射请求URL中绑定的占位符 
     * @param id 
     */ 
    @RequestMapping("/test04/{id}") 
    public void test04(@PathVariable(value = "id") Integer id){ 
        System.out.println("id: " + id); 
    }
```
```
    /** 
     * 注解@RequestParam绑定请求参数到方法入参  适用于get请求 
     * 注意：当请求参数username不存在时会有异常发生,可以通过设置属性required=false解决, 
     * @param username 
     * @param password 
     */ 
    @RequestMapping("/test05") 
    public void test05(@RequestParam(value="username") String username, @RequestParam(value="password", required=false, defaultValue="123456") String password){ 
        System.out.println("username: " + username); 
        System.out.println("password: " + password); 
    }
```
```
    /** 
     * 注解@RequestBody 适用于post请求  Content-Type必须为application/json
     * 解析客户端（移动设备、浏览器等）发送过来的json数据，并封装到实体类中 
     * @param params 
     */ 
    @RequestMapping("/test06") 
    public void test06(@RequestBody String params){ 
        JSONObject json = JSONObject.parseObject(params); 
        System.out.println("username: " + json.getString("username")); 
        System.out.println("password: " + json.getString("password")); 
    }
```
```
  /** 
     * 注解@RequestBody 适用于post请求  Content-Type必须为application/json
     * 解析客户端（移动设备、浏览器等）发送过来的json数据，并封装到实体类中 
     * @param user 
     */ 
    @RequestMapping("/test07") 
    public void test07(@RequestBody User user){ 
        System.out.println("username: " + user.getUsername()); 
        System.out.println("password: " + user.getPassword()); 
    }
```
```
 /** 
     * json转集合 
     * @param map 
     */ 
    @RequestMapping("/test08") 
    public void test08(@RequestBody Map<String,Object> map){ 
        System.out.println("username: " + map.get("username")); 
        System.out.println("password: " + map.get("password")); 
    }
```
```
    /** 
     * 接收数组 适用于post请求  参考格式：["2","3","4"] 
     * @param id3s 
     */ 
    @RequestMapping(value = "/accept-arr-object") 
    public void acceptArray(@RequestBody String[] id3s) { 
        System.out.println(JSON.toJSONString(id3s)); 
    }
```
```
    /** 
     * 文件上传 
     * @param file 
     * @return 
     */ 
    @RequestMapping(value = "/upload",method = RequestMethod.POST) 
    // 1.使用MultipartFile file接受上传的文件 
    public @ResponseBody String upload(MultipartFile file) { 
        try { 
            // 2. 使用FileUtils.writeByteArrayToFile快速写文件到磁盘。 
            FileUtils.writeByteArrayToFile(new File("e:/upload/"+ file.getName()),file.getBytes()); 
            return "ok"; 
        } catch (IOException e) { 
            e.printStackTrace(); 
            return "wrong"; 
        } 
    }
```
三个注解说明：

* @RequestMapping，用来映射请求的url地址

* @RequestParam，绑定单个请求数据，可以是URL中的数据，表单提交的数据或上传的文件； 

* @PathVariable，绑定URL模板变量值；


如有不对，欢迎指正！



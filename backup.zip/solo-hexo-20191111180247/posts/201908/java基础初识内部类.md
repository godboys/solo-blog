title: java基础——初识内部类
date: '2019-08-28 21:20:12'
updated: '2019-08-28 23:01:42'
tags: [内部类]
permalink: /articles/2019/08/28/1566998412116.html
---
![](https://img.hacpai.com/bing/20190226.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**引言**
今天在发版的时候，出现一个类，包含了十几个内部类，但是使用idea编译的时候，却又找不到这几个内部类的class文件，不要用idea去找，直接打开文件所在的目录就可以看见了，本篇主要是回顾一下内部类基本结构。
**什么是内部类？**
在一个.java源文件中，只能定义一个类名与文件名完全一致的公开类，使用public class 关键字修饰。在面向对象语言中，任何一个类都可以在内部定义另外一个类。前者属于外部类，后者属于内部类，因为内部类本身就是类的一个属性，与其它属性定义方式一致。

* 属性字段：private static String str，由访问控制符、是否是静态、类型、变量名组成
* 内部类：private static class Inner{}，也是按照这样的顺序定义的，其中类型可以为class、enum等。

---
**作用范围**

内部类分静态和非静态的，它可以出现在属性、方法体、表达式中以及匿名出现。
具体分为如下四种：

*  静态内部类，如：static class StaticInnerClass{}；
*  成员内部类，如：private class InstanceInnerClass{}；
*  局部内部类，如：class  MethodClass1 {} (定义在方法或者表达式内部)；
*  匿名内部类，如：(new Thread(){}).start()。

---
**定义方式示例**
```
public class OuterClass { 
     
    //成员内部类 
    private class InstanceInnerClass {}; 
     
    //静态内部类 
    static class StaticInnerClass {}; 

    public static void main(String[] args) { 
        //二个匿名内部类 
        (new Thread() {}).start(); 
        (new Thread() {}).start(); 
        // 二个方法内部类（局部内部类） 
        class MethodClass1 {}; 
        class MethodClass2 {}; 
    } 
}
```
编译后class文件如图所示
![image.png](https://img.hacpai.com/file/2019/08/image-3f549247.png)
无论什么类型的内部类，都会编译成独立的class文件。

---
**外部类与内部类的命名方式**

* 外部类与内部类之间使用$符号分格
* 匿名内部类使用数字进行编号
* 方法内部类，在类名前还有一个编号标识是哪个方法

示例代码中匿名内部类和静态内部类比较常用的方式
匿名类来启动线程，节约若干代码。
静态内部类，外部可以使用OuterClass.StaticInnerClass直接访问，类加载与外部类在同一个阶段进行。
在jdk源码中，定义包内可见静态内部类的好处：
1.作用域不会扩散到包外。
2.可以通过“外部类.内部类“ 的方式直接访问
3.内部类可以访问外部类中的所有静态属性和方法

下篇将介绍内部类的作用及使用

如有不对，欢迎指正！




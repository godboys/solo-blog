title: java基础——基本数据类型
date: '2019-08-16 15:52:08'
updated: '2019-08-16 16:01:23'
tags: [基本数据]
permalink: /articles/2019/08/16/1565941928562.html
---
![](https://img.hacpai.com/bing/20181122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 基本数据类型

  

### 整型

  

* 最小数据类型

  

byte  在内存中占8位(bit)，即1个字节，取值范围-128~127，默认为0；

  

* 短整型

  

short 在内存中占16位，即2个字节，取值范围-32768~32717，默认值0

  

* 整型

  

int   用于存储整数，在内在中占32位，即4个字节，取值范围-2147483648~2147483647，默认值0

  

* 长整型

  

long  在内存中占64位，即8个字节-2^63~2^63-1，默认值0L

  

### 浮点型

  

* 单精度

  

float 在内存中占32位，即4个字节，用于存储带小数点的数字（与double的区别在于float类型有效小数点只有6~7位），默认值0

  

* 双精度

  

double  双精度浮点型，用于存储带有小数点的数字，在内存中占64位，即8个字节，默认值0

  

### 字符型

  

char  用于存储单个字符，占16位，即2个字节，取值范围0~65535，默认值为空

  

### 布尔型

boolean 占1个字节，用于判断真或假（仅有两个值，即true、false），默认值false


## 总结
| 类型 |  表示 |  作用 |  占用内存 |  取值范围 |  默认值 |
| --- | --- | --- |
| 最小数据类型 |  byte |  存储整数 |  1 |  -128~127 |  0 |
| 短整型 |  short |  存储整数 |  2 |  -32768~32717 |  0 |
| 整形 |  int |  存储整数 |  4 |  -2147483648~2147483647 |  0 |
| 长整形 |  long |  存储整数 |  8 |  -263~263-1 |  0 |
| 单精度浮点型 |  float |  存储带有小数点的数字 |  4 |   |  0.0 |
| 双精度浮点型 |  double |  存储带有小数点的数字 |  8 |   |  0.0 |
| 字符型 |  char |  存储单个字符 |  2 |  0~65535 |  null |
| 布尔型 |  boolean |  判断真或假(true,false) |  1 |   |  false |

代码

```
import org.junit.jupiter.api.Test;  
public class Basic_class {  
  
    private byte b;  
    private short s;  
    private int t;  
    private long l;  
    private float f;  
    private double d;  
    private char c;  
    private boolean bl;  
  
    @Test   
    public void test(){                                 // 输出结果
        System.out.println("byte的默认值: " + b);        // byte的默认值: 0  
        System.out.println("short的默认值: " + s);       // short的默认值: 0
        System.out.println("int的默认值: " + t);         // int的默认值: 0  
        System.out.println("long的默认值: " + l);        // long的默认值: 0  
        System.out.println("float的默认值: " + f);       // float的默认值: 0.0  
        System.out.println("double的默认值: " + d);      // double的默认值: 0.0  
        System.out.println("char的默认值: " + c);        // char的默认值:    
        System.out.println("boolean的默认值: " + bl);    // boolean的默认值: false
    }  
}

title: java容器之ArrayList
date: '2019-08-21 14:09:03'
updated: '2019-08-26 16:59:57'
tags: [java容器]
permalink: /articles/2019/08/21/1566367743931.html
---
![](https://img.hacpai.com/bing/20180215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**字段**  
```  
private static final int DEFAULT_CAPACITY = 10;  // 默认arrayList容量为10  
```  
```  
private static final Object[] EMPTY_ELEMENTDATA = {}; // 默认空数组   有参构造，参数为0时使用
```  
```  
private static final Object[] DEFAULTCAPACITY_EMPTY_ELEMENTDATA = {}; // 默认空数组  无参构造时使用  
```  
```  
transient Object[] elementData;  // 这才是真正保存数据的数组  
```  
```  
 private int size; // arrayList的实际元素数量  
```  
---
**初始化方法** 
  
```  
public ArrayList() {   // 无参构造方法默认空数组
        this.elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;   
    }  
```  
```  
public ArrayList(int initialCapacity) {  //  构造方法传入一个自定义初始化容量，指定数组大小
        if (initialCapacity > 0) {   
            this.elementData = new Object[initialCapacity];   
        } else if (initialCapacity == 0) {   
            this.elementData = EMPTY_ELEMENTDATA;   
        } else {   
            throw new IllegalArgumentException("Illegal Capacity: "+   
                                               initialCapacity);   
        }   
    }  
```  
```
public ArrayList(Collection<? extends E> c) { 
        elementData = c.toArray(); 
        if ((size = elementData.length) != 0) { 
            // c.toArray might (incorrectly) not return Object[] (see 6260652) 
            if (elementData.getClass() != Object[].class) 
                elementData = Arrays.copyOf(elementData, size, Object[].class); 
        } else { 
            // replace with empty array. 
            this.elementData = EMPTY_ELEMENTDATA; 
        } 
    }
```
---
**常用方法**  
  
添加对象  
```  
 public boolean add(E e) {   
        ensureCapacityInternal(size + 1);  // Increments modCount!!   最开始的时候size为0，一个元素都没有
        elementData[size++] = e;  //索引是从0才是的，size 为当前索引，size++ 表示 当前大小增加一位
        return true;   
    }  
``` 
```
private void ensureCapacityInternal(int minCapacity) { 
        if (elementData == DEFAULTCAPACITY_EMPTY_ELEMENTDATA) { 
            minCapacity = Math.max(DEFAULT_CAPACITY, minCapacity); 
        } 
        ensureExplicitCapacity(minCapacity); 
    }
```
```
 private void ensureExplicitCapacity(int minCapacity) { 
        modCount++; 

        // overflow-conscious code 
        if (minCapacity - elementData.length > 0)  //容量溢出，就要进行扩容了
            grow(minCapacity); 
    }
```
```
 private void grow(int minCapacity) {   //这个就是arraylist的扩容的核心方法了
        // overflow-conscious code 
        int oldCapacity = elementData.length;  //当前数组的长度
        int newCapacity = oldCapacity + (oldCapacity >> 1); // 当前数组长度的1.5倍进行扩容
        if (newCapacity - minCapacity < 0)  //判断新数组容量满不满足，满足就用扩容的，不满足就用所需要的
            newCapacity = minCapacity; 
        if (newCapacity - MAX_ARRAY_SIZE > 0)  // 判断是否超过最大容量
            newCapacity = hugeCapacity(minCapacity); 
        // minCapacity is usually close to size, so this is a win: 
        elementData = Arrays.copyOf(elementData, newCapacity); //将原来的数组的值，copy的新的数组当中，所以当数据量大的时候，频繁的进行拷贝会影响效率
    }
```
```
private static int hugeCapacity(int minCapacity) { 
        if (minCapacity < 0) // overflow 
            throw new OutOfMemoryError(); 
        return (minCapacity > MAX_ARRAY_SIZE) ? 
            Integer.MAX_VALUE : 
            MAX_ARRAY_SIZE; 
    }
```

---
 
按指定索引增加元素

``` 
 public void add(int index, E element) {   
        rangeCheckForAdd(index);   // 检查索引是否越界
  
        ensureCapacityInternal(size + 1);  // Increments modCount!!   
        System.arraycopy(elementData, index, elementData, index + 1,   
                         size - index); // 将目标数组向右移动一位
        elementData[index] = element;   
        size++;   
    }  
```
```
private void rangeCheckForAdd(int index) {  //检查数组
        if (index > size || index < 0) 
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index)); 
    }
```
---
arraylist移除元素的方法
```
public boolean remove(Object o) { 
        if (o == null) { 
            for (int index = 0; index < size; index++) 
                if (elementData[index] == null) { 
                    fastRemove(index); 
                    return true; 
                } 
        } else { 
            for (int index = 0; index < size; index++) 
                if (o.equals(elementData[index])) {  // 这里的equals方法，实际上用的是object类里的equals方法,只是比较地址值是否相等
                    fastRemove(index); 
                    return true; 
                } 
        } 
        return false; 
    }
```
```
 private void fastRemove(int index) {  //核心方法：将原来的数组排除要删除的索引，将索引之后元素复制到新的数组去，最后将最后一个元素置为null，留给GC回收。
        modCount++; 
        int numMoved = size - index - 1; 
        if (numMoved > 0) 
            System.arraycopy(elementData, index+1, elementData, index, 
                             numMoved);  // 这里实现了对指定索引值的覆盖，从而移除了指定索引的值
        elementData[--size] = null; // clear to let GC do its work 
    }

```
---
**总结**
arraylist的本质上是对数组进行操作，所以它拥有了数组的一切特性，如有序，可重复，查询快。
当它新增，删除数据的时候，涉及对数组的频繁拷贝，所以会降低性能。





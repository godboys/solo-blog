title: 调试Tomcat源码(一)
date: '2019-08-27 17:15:18'
updated: '2019-08-27 17:16:06'
tags: [tomcat源码]
permalink: /articles/2019/08/27/1566897317998.html
---
![](https://img.hacpai.com/bing/20181211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

环境：jdk1.8，tomcat1.8
tomcat1.8下载
[https://tomcat.apache.org/download-80.cgi](https://)
下载这个源代码，如图所示：
![image.png](https://img.hacpai.com/file/2019/08/image-ad1e074c.png)
github拉一下来的源码使用ant构建的，不太会，还要导jar包，所以这里采用maven引入所需jar包。
自己建一个pom.xml放入tomcat的根目录下
![image.png](https://img.hacpai.com/file/2019/08/image-f41a3a24.png)
配置如下，将以下内容拷入pom.xml下
```
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd"> 
    <modelVersion>4.0.0</modelVersion> 
    <groupId>org.apache.tomcat</groupId> 
    <artifactId>tomcat8</artifactId> 
    <name>tomcat8</name> 
    <version>8.0</version> 
    <build> 
        <finalName>tomcat8</finalName> 
        <sourceDirectory>java</sourceDirectory> 
        <resources> 
            <resource> 
                <directory>java</directory> 
            </resource> 
        </resources> 
        <testResources> 
            <testResource> 
                <directory>test</directory> 
            </testResource> 
        </testResources> 
        <plugins> 
            <plugin> 
                <groupId>org.apache.maven.plugins</groupId> 
                <artifactId>maven-compiler-plugin</artifactId> 
                <version>3.5.1</version> 
                <configuration> 
                    <encoding>UTF-8</encoding> 
                    <source>1.8</source> 
                    <target>1.8</target> 
                </configuration> 
            </plugin> 
            <plugin> 
                <groupId>org.apache.maven.plugins</groupId> 
                <artifactId>maven-jar-plugin</artifactId> 
                <version>2.6</version> 
            </plugin> 
        </plugins> 
    </build> 
    <dependencies> 
        <dependency> 
            <groupId>junit</groupId> 
            <artifactId>junit</artifactId> 
            <version>4.11</version> 
            <scope>test</scope> 
        </dependency> 
        <dependency> 
            <groupId>ant</groupId> 
            <artifactId>ant</artifactId> 
            <version>1.6.5</version> 
        </dependency> 
        <dependency> 
            <groupId>org.easymock</groupId> 
            <artifactId>easymock</artifactId> 
            <version>3.4</version> 
        </dependency> 

        <dependency> 
            <groupId>wsdl4j</groupId> 
            <artifactId>wsdl4j</artifactId> 
            <version>1.6.2</version> 
        </dependency> 
        <dependency> 
            <groupId>javax.xml</groupId> 
            <artifactId>jaxrpc</artifactId> 
            <version>1.1</version> 
        </dependency> 
        <dependency> 
            <groupId>org.eclipse.jdt.core.compiler</groupId> 
            <artifactId>ecj</artifactId> 
            <version>4.6.1</version> 
        </dependency> 
    </dependencies> 
</project>
```
![image.png](https://img.hacpai.com/file/2019/08/image-364b139f.png)
设置Main class：  
`org.apache.catalina.startup.Bootstrap `
设置VM options：
```
-Dcatalina.home=E:\project\SourceCode\tomcat     
-Dcatalina.base=E:\project\SourceCode\tomcat     
-Djava.endorsed.dirs=E:\project\SourceCode\tomcat\endorsed     
-Djava.io.tmpdir=E:\project\SourceCode\tomcat\temp     
-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager     
-Djava.util.logging.config.file=E:\project\SourceCode\tomcat\conf\logging.properties
```
**E:\project\SourceCode\tomcat 替换成自己的tomcat源码目录**
然后找到Bootstrap 类中的main()方法启动
![image.png](https://img.hacpai.com/file/2019/08/image-faeac186.png)
此时访问http://localhost:8080，出现报500错误。
解决办法：
在ContextConfig类configureStart() 方法中加入，如图所示代码：
![image.png](https://img.hacpai.com/file/2019/08/image-ad6619a2.png)

重新执行main()方法，即可出现首页
![image.png](https://img.hacpai.com/file/2019/08/image-63d82bfb.png)
tomcat内部细节，之后梳理。


如有不对之处，欢迎指出。



